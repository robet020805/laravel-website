<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', system-ui, -apple-system, sans-serif;
        }

        :root {
            --primary: #4f46e5;
            --primary-dark: #3730a3;
            --accent: #06b6d4;
            --danger: #e63946;
            --dark: #1e293b;
            --gray: #64748b;
            --light: #f1f5f9;
            --radius: 14px;
            --shadow: 0 10px 25px rgba(0,0,0,0.08);
            --transition: all 0.3s ease;
        }

        body {
            background: linear-gradient(135deg, #6366f1 0%, #06b6d4 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }

        .auth-card {
            width: 100%;
            max-width: 420px;
            background: white;
            border-radius: var(--radius);
            box-shadow: var(--shadow);
            overflow: hidden;
            transition: var(--transition);
        }

        .auth-card:hover {
            transform: translateY(-3px);
        }

        .card-header {
            padding: 28px 24px 20px;
            text-align: center;
            background: linear-gradient(135deg, var(--primary) 0%, var(--accent) 100%);
            color: white;
        }

        .card-header h1 {
            font-size: 26px;
            font-weight: 700;
            margin-bottom: 6px;
        }

        .card-header p {
            opacity: 0.9;
            font-size: 14px;
        }

        .card-body {
            padding: 28px 24px;
        }

        .alert-error {
            background: rgba(230, 57, 70, 0.08);
            color: var(--danger);
            padding: 12px 14px;
            border-radius: 10px;
            margin-bottom: 22px;
            display: flex;
            align-items: center;
            border-left: 4px solid var(--danger);
            font-size: 14px;
        }

        .alert-error i {
            margin-right: 8px;
            font-size: 16px;
        }

        .form-group {
            margin-bottom: 18px;
        }

        .form-label {
            display: block;
            margin-bottom: 6px;
            font-weight: 600;
            color: var(--dark);
            font-size: 14px;
        }

        .input-group {
            position: relative;
        }

        .input-icon {
            position: absolute;
            left: 14px;
            top: 50%;
            transform: translateY(-50%);
            color: var(--gray);
            font-size: 15px;
        }

        .form-control {
            width: 100%;
            padding: 14px 14px 14px 44px;
            border: 1.5px solid #e2e8f0;
            border-radius: 10px;
            font-size: 15px;
            transition: var(--transition);
            background-color: #f8fafc;
        }

        .form-control:focus {
            outline: none;
            border-color: var(--primary);
            background-color: white;
            box-shadow: 0 0 0 3px rgba(79,70,229,0.15);
        }

        .password-toggle {
            position: absolute;
            right: 14px;
            top: 50%;
            transform: translateY(-50%);
            color: var(--gray);
            cursor: pointer;
            font-size: 15px;
        }

        .btn {
            display: block;
            width: 100%;
            padding: 14px;
            border: none;
            border-radius: 10px;
            font-size: 15px;
            font-weight: 600;
            cursor: pointer;
            transition: var(--transition);
            text-align: center;
        }

        .btn-primary {
            background: var(--primary);
            color: white;
            box-shadow: 0 4px 12px rgba(79,70,229,0.25);
        }

        .btn-primary:hover {
            background: var(--primary-dark);
            transform: translateY(-2px);
        }

        .card-footer {
            padding: 18px 24px 24px;
            text-align: center;
            background-color: var(--light);
            border-top: 1px solid #e2e8f0;
        }

        .card-footer p {
            color: var(--gray);
            font-size: 14px;
        }

        .card-footer a {
            color: var(--primary);
            text-decoration: none;
            font-weight: 600;
        }

        .card-footer a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="auth-card">
        <div class="card-header">
            <h1>Selamat Datang</h1>
            <p>Masuk ke akun Anda untuk melanjutkan</p>
        </div>
        
        <div class="card-body">
            <!-- Alert Error -->
            <?php if($errors->any()): ?>
                <div class="alert-error">
                    <i class="fas fa-exclamation-circle"></i>
                    <div><?php echo e($errors->first()); ?></div>
                </div>
            <?php endif; ?>
            
            <form action="<?php echo e(route('login')); ?>" method="POST">
                <?php echo csrf_field(); ?>

                <!-- Username -->
                <div class="form-group">
                    <label class="form-label" for="username">Username</label>
                    <div class="input-group">
                        <i class="fas fa-user input-icon"></i>
                        <input type="text" id="username" name="username" class="form-control" placeholder="Masukkan username Anda" required>
                    </div>
                </div>

                <!-- Password -->
                <div class="form-group">
                    <label class="form-label" for="password">Password</label>
                    <div class="input-group">
                        <i class="fas fa-lock input-icon"></i>
                        <input type="password" id="password" name="password" class="form-control" placeholder="Masukkan password Anda" required>
                        <span class="password-toggle" id="passwordToggle"><i class="fas fa-eye"></i></span>
                    </div>
                </div>
                
                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-sign-in-alt"></i> Masuk
                </button>
            </form>
        </div>
        
        <div class="card-footer">
            <p>Belum punya akun? <a href="<?php echo e(route('register')); ?>">Daftar di sini</a></p>
        </div>
    </div>

    <script>
        // Toggle password
        const toggle = document.getElementById('passwordToggle');
        const pwd = document.getElementById('password');
        toggle.addEventListener('click', () => {
            const type = pwd.type === 'password' ? 'text' : 'password';
            pwd.type = type;
            const icon = toggle.querySelector('i');
            icon.classList.toggle('fa-eye');
            icon.classList.toggle('fa-eye-slash');
        });
    </script>
</body>
</html>
<?php /**PATH D:\Project Magang\Sistem-Inventaris-Barang-master\resources\views/auth/login.blade.php ENDPATH**/ ?>