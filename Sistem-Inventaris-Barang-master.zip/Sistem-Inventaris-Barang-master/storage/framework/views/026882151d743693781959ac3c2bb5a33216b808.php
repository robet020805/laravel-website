<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
	 <?php $__env->slot('head', null, []); ?> 
		<link rel="stylesheet" href="<?php echo e(asset('dist/vendor/datatables/buttons.dataTables.min.css')); ?>">
	 <?php $__env->endSlot(); ?>
	 <?php $__env->slot('title', null, []); ?> Laporan <?php $__env->endSlot(); ?>

	<?php if(session()->has('success')): ?>
	<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.alert','data' => ['type' => 'success','message' => ''.e(session()->get('success')).'']]); ?>
<?php $component->withName('alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['type' => 'success','message' => ''.e(session()->get('success')).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
	<?php endif; ?>

	<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.card','data' => []]); ?>
<?php $component->withName('card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
		 <?php $__env->slot('title', null, []); ?> Semua Laporan <?php $__env->endSlot(); ?>

		<table class="table table-hover mb-3">
			<thead>
				<th>Nama Barang</th>
				<th>Dari/Kepada</th>
				<th>Harga</th>
				<th>Stok</th>
				<th>Berat</th>
				<th>Tanggal</th>
				<th>Aksi</th>
			</thead>
			<tbody>
				<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<tr>
						<td><?php echo e($row->nama); ?></td>
						<td><?php echo e($row->orang); ?></td>
						<td><?php echo e($row->harga); ?></td>
						<td><?php echo e($row->jumlah); ?></td>
						<td><?php echo e($row->berat); ?>kg</td>
						<td><?php echo e($row->created_at->format('d-m-Y')); ?></td>
						<td><span class="badge badge-<?php echo e(($row->jenis == 'Barang Masuk') ? 'success' : 'danger'); ?>"><?php echo e($row->jenis); ?></span></td>
					</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				
			</tbody>
		</table>
	 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

	

	 <?php $__env->slot('script', null, []); ?> 
		<script src="<?php echo e(asset('dist/vendor/datatables/jquery.dataTables.min.js')); ?>"></script>
		<script src="<?php echo e(asset('dist/vendor/datatables/dataTables.bootstrap4.min.js')); ?>"></script>
		<script src="<?php echo e(asset('dist/vendor/datatables/dataTables.buttons.min.js')); ?>"></script>
		<script src="<?php echo e(asset('dist/vendor/datatables/jszip.min.js')); ?>"></script>
		<script src="<?php echo e(asset('dist/vendor/datatables/pdfmake.min.js')); ?>"></script>
		<script src="<?php echo e(asset('dist/vendor/datatables/vfs_fonts.js')); ?>"></script>
		<script src="<?php echo e(asset('dist/vendor/datatables/buttons.html5.min.js')); ?>"></script>
		<script>

			$(document).ready(function () {
		      $('table').DataTable({
			        dom: 'Bfrtip',
			        buttons: [
			            'excelHtml5',
			            'csvHtml5',
			            'pdfHtml5'
			        ]
			    } );
		    });
		</script>
	 <?php $__env->endSlot(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?><?php /**PATH D:\Project Magang\Sistem-Inventaris-Barang-master\resources\views/admin/laporan/index.blade.php ENDPATH**/ ?>