<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
	 <?php $__env->slot('title', null, []); ?> Daftar Supplier <?php $__env->endSlot(); ?>

	<?php if(session()->has('success')): ?>
	<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.alert','data' => ['type' => 'success','message' => ''.e(session()->get('success')).'']]); ?>
<?php $component->withName('alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['type' => 'success','message' => ''.e(session()->get('success')).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
	<?php endif; ?>

	<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.card','data' => []]); ?>
<?php $component->withName('card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
		 <?php $__env->slot('title', null, []); ?> Semua Supplier <?php $__env->endSlot(); ?>
		 <?php $__env->slot('option', null, []); ?> 
			<button class="btn btn-primary add"><i class="fas fa-plus"></i> Tambah Supplier</button>
		 <?php $__env->endSlot(); ?>

		<table class="table table-hover mb-3">
			<thead>
				<th>Nama Supplier</th>
				<th>Alamat Supplier</th>
				<th>Telepon</th>
				<th></th>
			</thead>
			<tbody>
				<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<tr>
						<td><?php echo e($row->nama); ?></td>
						<td><?php echo e($row->alamat); ?></td>
						<td><?php echo e($row->telepon); ?></td>
						<td class="text-center">
							<button class="btn btn-sm btn-info info" data-id="<?php echo e($row->id); ?>"><i class="fas fa-info-circle"></i></button>
							<button class="btn btn-sm btn-primary edit" data-id="<?php echo e($row->id); ?>"><i class="fas fa-edit"></i></button>
							<form action="<?php echo e(route('admin.supplier.destroy', $row->id)); ?>" style="display: inline-block;" method="POST">
							<?php echo csrf_field(); ?>
							<button type="button" class="btn btn-sm btn-danger delete"><i class="fas fa-trash"></i></button>
						</form>
						</td>
					</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				
			</tbody>
		</table>
	 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

	
	<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.modal','data' => []]); ?>
<?php $component->withName('modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
		 <?php $__env->slot('title', null, []); ?> 
			<h6 class="m-0 font-weight-bold text-primary">Tambahkan Supplier</h6>
		 <?php $__env->endSlot(); ?>
		 <?php $__env->slot('id', null, []); ?> add <?php $__env->endSlot(); ?>


		<form action="<?php echo e(route('admin.supplier.store')); ?>" method="post" class="form-group">
			<?php echo csrf_field(); ?>
			<div class="row">
				<div class="col-md-6">
					<div class="form-group">
						<label for="">Nama Supplier</label>
						<input type="text" class="form-control" name="nama" required="">
					</div>
				</div>
				<div class="col-md-6">
					<div class="form-group">
						<label for="">Alamat Supplier</label>
						<input type="text" class="form-control" name="alamat" required="">
					</div>
				</div>
			</div>
			<div class="form-group">
				<label for="">Telepon</label>
				<input type="text" class="form-control" name="telepon" required="">
			</div>
			<div class="form-group">
				<textarea name="catatan" id="" cols="30" rows="10" class="form-control" placeholder="Catatan"></textarea>
			</div>
			<button type="submit" class="btn btn-primary">Simpan</button>
		</form>
	 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

	
	<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.modal','data' => []]); ?>
<?php $component->withName('modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
		 <?php $__env->slot('title', null, []); ?> 
			<h6 class="m-0 font-weight-bold text-primary">Edit Gudang</h6>
		 <?php $__env->endSlot(); ?>
		 <?php $__env->slot('id', null, []); ?> edit <?php $__env->endSlot(); ?>


		<form action="<?php echo e(route('admin.supplier.update')); ?>" method="post" id="edit" class="form-group">
			<?php echo csrf_field(); ?>
			<input type="hidden" name="id" value="">
			<div class="row">
				<div class="col-md-6">
					<div class="form-group">
						<label for="">Nama Supplier</label>
						<input type="text" class="form-control" name="nama" required="">
					</div>
				</div>
				<div class="col-md-6">
					<div class="form-group">
						<label for="">Alamat Supplier</label>
						<input type="text" class="form-control" name="alamat" required="">
					</div>
				</div>
			</div>
			<div class="form-group">
				<label for="">Telepon</label>
				<input type="text" class="form-control" name="telepon" required="">
			</div>
			<div class="form-group">
				<textarea name="catatan" id="" cols="30" rows="10" class="form-control" placeholder="Catatan"></textarea>
			</div>
			<button type="submit" class="btn btn-primary">Simpan</button>
		</form>
	 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

	
	<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.modal','data' => []]); ?>
<?php $component->withName('modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
		 <?php $__env->slot('title', null, []); ?> 
			<h6 class="m-0 font-weight-bold text-primary">Informasi Gudang</h6>
		 <?php $__env->endSlot(); ?>
		 <?php $__env->slot('id', null, []); ?> info <?php $__env->endSlot(); ?>

		<div class="row">
			<div class="col-md-6">
				<span>Nama Supplier</span>
			</div>
			<div class="col-md-6">
				: <span id="nama"></span>
			</div>
		</div>

		<div class="row">
			<div class="col-md-6">
				<span>Alamat Supplier</span>
			</div>
			<div class="col-md-6">
				: <span id="alamat"></span>
			</div>
		</div>

		<div class="row">
			<div class="col-md-6">
				<span>Telepon</span>
			</div>
			<div class="col-md-6">
				: <span id="telepon"></span>
			</div>
		</div>

		<div class="row">
			<div class="col-md-6">
				<span>Catatan</span>
			</div>
			<div class="col-md-6">
				: <span id="catatan"></span>
			</div>
		</div>
	 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

	 <?php $__env->slot('script', null, []); ?> 
		<script src="<?php echo e(asset('dist/vendor/datatables/jquery.dataTables.min.js')); ?>"></script>
		<script src="<?php echo e(asset('dist/vendor/datatables/dataTables.bootstrap4.min.js')); ?>"></script>
		<script>
			$('.add').click(function() {
				$('#add').modal('show')
			})

			$('.info').click(function() {
				const id = $(this).data('id')

				$.get(`<?php echo e(route('admin.supplier.info')); ?>?id=${id}`, function(data) {
					$('#nama').text(data.nama)
					$('#alamat').text(data.alamat)
					$('#telepon').text(data.telepon)
					$('#catatan').text(data.catatan)
				})

				$('#info').modal('show')
			})

			$('.edit').click(function() {
				const id = $(this).data('id')

				$.get(`<?php echo e(route('admin.supplier.info')); ?>?id=${id}`, function(data) {
					$('#edit input[name="id"]').val(id)

					$('#edit input[name="nama"]').val(data.nama)
					$('#edit input[name="alamat"]').val(data.alamat)
					$('#edit input[name="telepon"]').val(data.telepon)
					$('#edit textarea[name="catatan"]').val(data.catatan)
				})

				$('#edit').modal('show')
			})

			$('.delete').click(function(e){
				e.preventDefault()
				Swal.fire({
				  title: 'Ingin menghapus?',
				  text: 'Data akan dihapus permanen',
				  icon: 'warning',
				  showCancelButton: true,
				  confirmButtonText: 'Hapus',
				  cancelButtonText: 'Batal'
				}).then((result) => {
					if (result.isConfirmed) {
				  		$(this).parent().submit()
					} 
				})

			})

			$(document).ready(function () {
		      $('table').DataTable();
		    });
		</script>
	 <?php $__env->endSlot(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?><?php /**PATH D:\Project Magang\Sistem-Inventaris-Barang-master\resources\views/admin/supplier/index.blade.php ENDPATH**/ ?>