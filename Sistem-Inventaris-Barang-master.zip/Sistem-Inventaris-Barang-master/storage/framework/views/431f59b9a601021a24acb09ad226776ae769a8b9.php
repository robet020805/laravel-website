<div class="alert alert-<?php echo e($type); ?>">
	<?php echo e($message); ?>

</div><?php /**PATH D:\Project Magang\Sistem-Inventaris-Barang-master\resources\views/components/alert.blade.php ENDPATH**/ ?>