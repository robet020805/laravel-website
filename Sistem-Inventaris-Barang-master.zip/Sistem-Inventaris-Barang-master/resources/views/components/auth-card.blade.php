<div class="card shadow-sm my-5">
        <div class="card-body p-0">
            <div class="row">
                <div class="col-lg-12">
                    <div class="login-form">
                        <div class="text-center">
                            <h1 class="h4 text-gray-900 mb-4">{{ $title }}</h1>
                        </div>
                        {{ $slot }}
                    </div>
                </div>
            </div>
        </div>
    </div>